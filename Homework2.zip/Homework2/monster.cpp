#include <iostream>
#include "monster.h"
using namespace std;

Monster::Monster(string n, int l, int st, Sword sw, Shield sh, int lvl)
    : Character(n, l, st, sw, sh)  // base constructor call (like Point -> Circle in slides)
{
  
    level = lvl;   //just assign
}

int Monster::GetLevel()
{
    return level; // Getting the level
}

void Monster::Print()
{

    Character::Print();  // I want to print base info first because it already prints life, route, sword, shield

    cout << "Monster level=" << level << endl; // then I add my monster-only info
}

