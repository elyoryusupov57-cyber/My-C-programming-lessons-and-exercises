#ifndef BOSS_H
#define BOSS_H

#include "monster.h"
class Hero;

class Boss : public Monster
{
public:
    Boss(string, int, int, Sword, Shield, int, int);

    int GetHeads();

    void Eat(Hero &);

    virtual void Print();

private:
    int heads;
};

#endif

