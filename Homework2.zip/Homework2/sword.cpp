#include "sword.h"

Sword::Sword(int w, int q)// constructor for sword
{
	weight = w;
	quality = q;	// assigning values after checking
	
	
	(w < 2) ? w : 2; //checking the limits and if match putting the right one
	(w > 5) ? w : 5;
	(q < 1) ? q : 1;
	(q > 6) ? q : 6;
}

Sword::~Sword()// destructor
{
}

int Sword::Damage()
{
	int dmg = weight * quality;
	WearAndTear(); // quality gets reduced every time we use sword
	return dmg;
}

void Sword::WearAndTear()
{
	if (quality > 1)
		quality--; // reduces quality by 1
	// no quality less than 1
}

void Sword::Sharpen()
{
	if (quality < 6)
		quality += 2; //  increases quality (
	if (quality > 6)
		quality = 6; // limit check
}

int Sword::GetWeight()
{
	return weight;// return weight of the sword
}

int Sword::GetQuality()
{
	return quality;// return quality of the sword
}
