#ifndef CHARACTER_H
#define CHARACTER_H

#include <string>
#include "sword.h"
#include "shield.h"
using namespace std;

class Character
{
public:
	Character(string, int, int, Sword, Shield); 
	~Character();                              
	bool Hit(int);                              
	int Attack();                               
	int Defence();                             
	void Go(char);                              
	int GetLife();                              
	void Print();                              
	Sword GetSword();                        
	Shield GetShield();
	void SetLife(int);                      
private:
	string name;
	int life;
	int strength;
	char path[10];   
	int index;       
	Sword sword;     
	Shield shield;  
};

#endif
