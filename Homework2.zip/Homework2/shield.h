#ifndef SHIELD_H
#define SHIELD_H

class Shield
{
public:
	Shield(int, int); 
	~Shield();         
	int Block();       
	void Destruction();
	void Repair();     
	int GetSize();     
	int GetProtection();
private:
		int size;        
		int protection;  																						
};

#endif
