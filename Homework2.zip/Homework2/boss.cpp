#include <iostream>
#include "boss.h"
#include "hero.h"
using namespace std;

Boss::Boss(string n, int l, int st, Sword sw, Shield sh, int lvl, int h)// adding the construction
    : Monster(n, l, st, sw, sh, lvl)
{
    heads = h; // asssingning the head to h
}

int Boss::GetHeads()
{
    return heads; // showing the the result for heads
}

void Boss::Eat(Hero &h)
{
    int heroLife = h.GetLife();
    h.Hit(heroLife); // hero is now dead
    heads = heads + 1;// +1 for bosss

    
    SetLife(GetLife() + heroLife);

    cout << "Boss ate hero, heads now=" << heads << endl;
}

void Boss::Print()
{
    Monster::Print();
    cout << "Boss heads=" << heads << endl;
}

