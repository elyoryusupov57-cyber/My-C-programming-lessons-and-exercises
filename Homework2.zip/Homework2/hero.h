#ifndef HERO_H
#define HERO_H

#include "character.h"
class Monster; // forward declaration

class Hero : public Character
{
public:
    Hero(string, int, int, Sword, Shield, int);

    void Kill(Monster &);

    virtual void Print();

private:
    int experience;
};

#endif

