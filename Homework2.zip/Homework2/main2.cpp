#include <iostream>
#include <ctime>
#include <cstdlib>

#include "hero.h"
#include "monster.h"
#include "boss.h"

using namespace std;

char RandomDir()
{
    int r = rand() % 4; //assingning the 4 diredtrions
    if(r == 0) return 'w';
    if(r == 1) return 's';
    if(r == 2) return 'a';
    return 'd';
}

int RandomHit()
{
    // random 5..10
    return 5 + (rand() % 6);
}

int main()
{
    srand((unsigned)time(0)); // everrutime it wiill be randim
    

    // I just pick some sword/shield values from the homework 1
    Sword s1(4, 6);
    Shield sh1(3, 3);

    Sword s2(2, 3);
    Shield sh2(4, 4);

    Sword s3(5, 5);
    Shield sh3(2, 5);

    Hero h("HeroHugo", 8, 6, s1, sh1, 0);
    Monster m("MonsterChris", 7, 5, s2, sh2, 2);//  1) create 1 hero, monster, boss
    Boss b("BossJohn", 10, 7, s3, sh3, 5, 1);

    cout << "\n--- FIRST PRINT ---\n";
    h.Print();
    m.Print();
    b.Print();

    cout << "\n--- ACTIONS ---\n";
    h.Kill(m);
    b.Eat(h);

    cout << "\n--- SECOND PRINT ---\n";
    h.Print();
    m.Print();
    b.Print();

    Character* arr[9];

    arr[0] = new Hero("hMatt", 7, 5, s1, sh1, 0);
    arr[1] = new Hero("hRice", 8, 6, s1, sh1, 0); // 2) array of 9 characters (3 hero, 3 monster, 3 boss)
    arr[2] = new Hero("hHugo", 9, 7, s1, sh1, 0);

    arr[3] = new Monster("mTed", 7, 5, s2, sh2, 1);
    arr[4] = new Monster("mJhon", 8, 6, s2, sh2, 2);
    arr[5] = new Monster("mSed", 9, 7, s2, sh2, 3);

    arr[6] = new Boss("bMarcial", 10, 7, s3, sh3, 4, 1);
    arr[7] = new Boss("bLily", 10, 7, s3, sh3, 5, 2);
    arr[8] = new Boss("bBarney", 10, 7, s3, sh3, 6, 3);

    cout << "\n---######### PRINTing  ARRAY  #########---\n";
    for(int i=0; i<9; i++)
        arr[i]->Print();

    
    for(int it=0; it<5; it++) //  5 iterations: random go + hit(5..10), then print all
    {
        cout << "\n==******* Round " << (it+1) << " *****===\n";

        for(int i=0; i<9; i++)
        {
            arr[i]->Go(RandomDir());     // from the first homework func  Go()
            arr[i]->Hit(RandomHit());    // from the first homework func Hit()
        }

        for(int i=0; i<9; i++)
            arr[i]->Print();
    }

    
    for(int i=0; i<9; i++) // cleanup
    {
        delete arr[i];
        arr[i] = 0;
    }

    system("PAUSE");
    return 0;
}

