#ifndef MONSTER_H
#define MONSTER_H

#include "character.h"


class Monster : public Character  // Monster is-a Character 
{
public:
    Monster(string, int, int, Sword, Shield, int);  // I reuse same Character constructor params, and just add "level"

    int GetLevel();


    virtual void Print();  // override Print so polymorphism works
protected:
    int level;
};

#endif

