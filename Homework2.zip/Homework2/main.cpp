#include <iostream>
#include <ctime>
#include "sword.h"
#include "shield.h"
#include "character.h"
using namespace std;

// Fight function 
bool Fight(Character &ch1, Character &ch2)
{
	if (ch1.GetLife() <= 0 || ch2.GetLife() <= 0)	// i checked  both characters are alive
	{
		cout << "One of the them is dead!" << endl;
		return false;
	}

	int attack = ch1.Attack();
	int defense = ch2.Defence();
	int damage = attack - defense;

	if (damage < 0) damage = 0;// defense stronger than attack, damage becomes 0

	cout << "Damage done: " << damage << endl;

	
	ch2.Hit(damage);// second one hits with the damage
	return true;
}

void Brawl(Character &c1, Character &c2)
{
    
    int round = 1;

    while (c1.GetLife() > 0 && c2.GetLife() > 0) //  while to  continue fight till one dies
    {
        cout << "\n***** Round " << round << " **********\n" << endl;

        // first attacker c1 to c2
        Fight(c1, c2);

        if (c2.GetLife() <= 0) {
            cout << c2.GetLife() << endl;// if one dies 
            break;
        }

        Fight(c2, c1); // second attacker c2 to c1


        if (c1.GetLife() <= 0) {
            cout << c1.GetLife() << endl;// // if one  dies program dies
            break;
        }

        cout << " After  round: " << round << endl;
        cout << " ******- " ;
        c1.Print();                     // after every round it shows the results
        cout << " ******- " ;
        c2.Print();

        // continuing till one of them dies
        round++;
    }

    cout << "\n ************ FIGHT IS OVER !!! *************\n"  << endl;
    if (c1.GetLife() > 0 && c2.GetLife() == 0) { // iff one dies other will be winner
        cout << "Winner: ";
        c1.Print();
    } else if (c2.GetLife() > 0 && c1.GetLife() == 0) {// vise versa
        cout << "Winner: ";
        c2.Print();
    } else {
        cout << "Both are alive " << endl;
    }
}


int main()
{
	srand((unsigned)time(0));
	Sword s1(4, 6);
	Shield sh1(3, 3);
	Character c1("Chris", 7, 5, s1, sh1); 

	Sword s2(2, 3);
	Shield sh2(4, 7);
	Character c2("Matt", 10, 7, s2, sh2);

	c1.Go('s');
	c2.Go('d'); //testing the movement 
	c1.Go('a');
	c2.Go('w');

	cout << " \n########## First dispute ##########\n";
	Fight(c1, c2);
	Fight(c2, c1);

	cout << endl << "latest info:" << endl;
	c1.Print();
	c2.Print();
	
	Brawl(c1, c2); // func for the fight till death
	

	system("PAUSE");
	return 0;
}

