#include "shield.h"

Shield::Shield(int s, int p)
{
	size = s;
	protection = p;
	(s < 0) ? s : 0;// checks range limits and sets values for the contruxtion
	(s > 4) ? s : 4;
	(p < 1) ? p : 1;
	(p > 5) ? p : 5;
}

Shield::~Shield()
{
}

int Shield::Block()
{
	int block = size * protection;
	Destruction(); // after block, size is reduced
	return block;
}

void Shield::Destruction()
{
	if (size > 0)// decreases shield size by 1 but not less than 0
		size--;
}

void Shield::Repair()
{
	if (size < 4)
		size += 2; // increases shield size by 2 but not more than 4
	if (size < 4)
		size = 4;
}

// returns size value
int Shield::GetSize()
{
	return size;
}

// returns protection value
int Shield::GetProtection()
{
	return protection;
}

