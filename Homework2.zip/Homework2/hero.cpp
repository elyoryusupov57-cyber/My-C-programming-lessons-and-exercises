#include <iostream>
#include "hero.h"
#include "monster.h"
using namespace std;

Hero::Hero(string n, int l, int st, Sword sw, Shield sh, int exp) // construction 
    : Character(n, l, st, sw, sh)
{
    experience = exp; // assigninng
}

void Hero::Kill(Monster &m)
{
    //  I don't have direct access to Monster life (private in Character),
    // so I use GetLife() and Hit() like a normal user of the class.

    int gained = m.GetLife() * m.GetLevel();
    experience += gained;

    // ki;lling the monster: hitting exactly remaining life
    m.Hit(m.GetLife());

    cout << "Hero gained exp = " << gained << " (total=" << experience << ")" << endl;
}

void Hero::Print()
{
    Character::Print(); // assigning the Print() func to experience
    cout << "Hero experience=" << experience << endl;
}

