#ifndef SWORD_H
#define SWORD_H

class Sword
{
public:
	Sword(int, int);  // all the functions 
	~Sword();         
	int Damage();     
	void WearAndTear(); 
	void Sharpen();     
	int GetWeight();    
	int GetQuality();   
	int weight;   
	int quality;  
};

#endif
