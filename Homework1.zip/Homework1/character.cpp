#include <iostream>
#include "character.h"
using namespace std;

Character::Character(string n, int l, int st, Sword sw, Shield sh)// constructor with name, life, strength and both sword and shield
	: sword(sw), shield(sh)
{
	name = n;

	life = l;
	strength = st;
	
	(l < 1) ? l : 1;
	(l > 10) ? l : 10;
	(st < 1) ? st : 1;// checking if life and strength are inside allowed range
	(st > 10) ? st : 10;
	index = 0;
}

// destructor prints message when character dies or goes out of scope
Character::~Character()
{
	cout << "Game over for " << name << endl;
}

// Hit() is used when character receives damage
// reduces life and checks if still alive
bool Character::Hit(int dmg)
{
	if (life <= 0)
		return false; // already dead
	life -= dmg;
	if (life < 0) life = 0; // life can't be negative
	return (life > 0);
}

// Attack() combines strength and sword damage
int Character::Attack()
{
	return strength + sword.Damage();
}

int Character::Defence()// combines half of strength and shield block
{
	return (strength / 2) + shield.Block();
}


void Character::Go(char dir)// Go() func records movement direction if character is alive
{
	if (life <= 0)
	{
		cout << name << " is dead " << endl;
		return;
	}
	if (dir == 'w' || dir == 'a' || dir == 's' || dir == 'd')
	{
		path[index % 10] = dir; // keeps only last 10 moves
		index++;
	}
	else
	{
		cout << "Wrong input!" << endl;
	}
}

int Character::GetLife()
{
	return life;// returns how much life is left
}

Sword Character::GetSword()
{
	return sword;// return sword and shield 
}

Shield Character::GetShield()
{
	return shield;
}

// Print()  func shows character info
void Character::Print()
{
	cout << "Name: " << name << endl;
	if (life > 0)
		cout << "Alive, life=" << life << endl;
	else
		cout << "Dead" << endl;

	cout << "Route: ";
	for (int i = 0; i < index && i < 10; i++)
		cout << path[i] << " ";
	cout << endl;

	cout << "Sword weight=" << sword.GetWeight() << " quality=" << sword.GetQuality() << endl;
	cout << "Shield size=" << shield.GetSize() << " protection=" << shield.GetProtection() << endl;
}

