#ifndef CHARACTER_H
#define CHARACTER_H

#include <iostream>
#include <string>
using namespace std;

class Character
{
    // We need friend functions for << and >>
    // because cout and cin are not part of the class.
    friend ostream& operator<<(ostream&, const Character&);
    friend istream& operator>>(istream&, Character&);

public:
    Character(string = "NoName", int = 5, int = 5);  // Constructor with default values.

    int GetLife() const;
    int GetStrength() const;

    // Assignment operator (=)
    // Allows copying one Character to another.
    Character& operator=(const Character&);
    Character operator++();
    Character operator++(int);
    Character operator--();
    Character operator--(int);

    // Comparison operators
    // comparison must be based on life * strength.
    bool operator>(const Character&) const;
    bool operator<(const Character&) const;
    bool operator==(const Character&) const;
    bool operator!=(const Character&) const;

private:
    string name;
    int life;
    int strength;

    // Helper function used internally for comparisons.
    int Power() const;
};

#endif

