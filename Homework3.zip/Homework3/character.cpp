#include "character.h"

Character::Character(string n, int l, int s)
{
    name = n;
    life = (l < 0) ? 0 : l;   // life cannot be negative
    strength = s; // Assigns name, life and strength.
}

int Character::GetLife() const
{
    return life;
}

int Character::GetStrength() const // inpiut of the strenth
{
    return strength;
}

int Character::Power() const // This function calculates the power value.
{
    return life * strength;
}


Character& Character::operator=(const Character& c)// Copies all fields from another Character.
{
    if(this == &c) return *this;

    name = c.name;
    life = c.life;
    strength = c.strength;

    return *this;
}

Character Character::operator++()// Prefix increment (++c)
{
    life++; // Increase life and return updated object.
    return *this;
}

Character Character::operator++(int)// Postfix increment (c++)
{
    Character temp = *this;// Return old value, then increase life
    life++;
    return temp;
}

Character Character::operator--()//Prefix decrement (--c)
{
    if(life > 0) life--; // Decrease life but do not allow it to go below 0.
    return *this;
}

Character Character::operator--(int)// Postfix decrement (c--)
{
    Character temp = *this;// Return old value, then decrease life.
    if(life > 0) life--;
    return temp;
}

bool Character::operator>(const Character& c) const// Greater-than comparison
{
    return Power() > c.Power();
}

bool Character::operator<(const Character& c) const // less than comparison
{
    return Power() < c.Power();
}

bool Character::operator==(const Character& c) const//. equality
{
    return Power() == c.Power();
}

bool Character::operator!=(const Character& c) const // noequal
{
    return !(*this == c);
}

ostream& operator<<(ostream& out, const Character& c)// Allows printing Character using cout.
{
    out << c.name
        << " life=" << c.life
        << " strength=" << c.strength
        << " power=" << (c.life * c.strength);
    return out;
}

istream& operator>>(istream& in, Character& c)// Allows reading Character using cin.
{
    in >> c.name >> c.life >> c.strength;


    if(c.life < 0) c.life = 0;// correcting the wring format

    return in;
}
