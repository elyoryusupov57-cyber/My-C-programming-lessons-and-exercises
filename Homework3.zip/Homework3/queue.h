#ifndef QUEUE_H
#define QUEUE_H

#include <iostream>
using namespace std;

// Template Queue class.
// Template allows using Queue with any type (Character, int, etc.).
template<class T>
class Queue
{
public:
    // Constructor with default size.
    Queue(int = 20);

    // Destructor frees dynamic memory.
    ~Queue();

    // Adds element to the end of the queue.
    void enqueue(T);

    // Removes first element from the queue.
    T dequeue();

    // Prints all elements in the queue.
    void PrintQueue() const;

    // Sorts queue in ascending order.
    void Sort();

private:
    T* data;     // dynamic array for queue elements
    int size;    // maximum size
    int count;   // current number of elements
};

template<class T>
Queue<T>::Queue(int s)
{
    size = s;
    count = 0;
    data = new T[size];
}

template<class T>
Queue<T>::~Queue()
{
    delete[] data;
}

template<class T>
void Queue<T>::enqueue(T x)
{
    if(count < size)
        data[count++] = x;// Add element if queue is not full.
}

template<class T>
T Queue<T>::dequeue()
{
    if(count == 0) return T();  // If queue is empty, return default object.

    T first = data[0];// Save first element (FIFO).

    // Shift remaining elements left.
    for(int i = 0; i < count - 1; i++)
        data[i] = data[i + 1];

    count--;
    return first;
}
template<class T>
void Queue<T>::PrintQueue() const
{
    for(int i = 0; i < count; i++)
        cout << data[i] << endl;
}

template<class T>
void Queue<T>::Sort()
{
    for(int i = 0; i < count; i++)
        for(int j = 0; j < count - 1; j++) // Works because operator> is overloaded for Character.
            if(data[j] > data[j + 1])
            {
                T tmp = data[j];
                data[j] = data[j + 1];
                data[j + 1] = tmp;
            }
}

#endif

