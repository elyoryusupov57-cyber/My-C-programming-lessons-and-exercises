#include <iostream>
#include <ctime>
#include <cstdlib>
#include "character.h"
#include "queue.h"

using namespace std;

int main()
{
    srand(time(0)); // random gen

    // Create queue of Character objects.
    Queue<Character> q;

    for(int i = 0; i < 10; i++)// Add 10 Character objects to the queue.
    {
        Character c("C", rand()%10, rand()%10 + 1);
        q.enqueue(c);
    }

    cout << "Before sort:\n"; //printing thr queu
    q.PrintQueue();

    // Sort queue in ascending order.
    q.Sort();

    cout << "\nAfter sort:\n"; // Printing after sorting.
    q.PrintQueue();

    cout << "\nRemove 5:\n";  // Removing 5 elements 
    for(int i = 0; i < 5; i++)
        cout << q.dequeue() << endl;

    cout << "\nAfter removing 5:\n";// Printing remaining 
    q.PrintQueue();

    return 0;
}

